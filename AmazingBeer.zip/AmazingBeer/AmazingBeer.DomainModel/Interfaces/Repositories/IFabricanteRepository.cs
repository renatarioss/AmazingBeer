﻿using AmazingBeer.DomainModel.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace AmazingBeer.DomainModel.Interfaces.Repositories
{
    public interface IFabricanteRepository : IRepository<Fabricante, Guid>
    {
        IEnumerable<Fabricante> FindByName(string nome);
    }
}
