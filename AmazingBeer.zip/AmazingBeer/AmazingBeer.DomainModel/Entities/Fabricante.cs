﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmazingBank.DomainModel.Entities
{
    public class Fabricante : EntityBase<Guid>
    {
        public string Nome { get; set; }
        public string SiteUrl { get; set; }
        public string CNPJ { get; set; }
    }
}
