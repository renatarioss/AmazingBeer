﻿using AmazingBeer.DomainModel.Entities;
using AmazingBeer.DomainModel.Interfaces.Repositories;
using AmazingBeer.Infrastructure.DataAccess.Contexts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AmazingBeer.Infrastructure.DataAccess.Repositories
{
    public class CervejeiroEntityFrameworkRepository : ICervejeiroRepository
    {
        private readonly AmazingBeerContext _db;

        public CervejeiroEntityFrameworkRepository(AmazingBeerContext db)
        {
            _db = db;
        }
  
        public void Create(Cervejeiro entity)
        {
            _db.Cervejeiros.Add(entity);
            _db.SaveChanges();
        }

        public void Delete(Guid id)
        {
            _db.Remove(Read(id));
            _db.SaveChanges();
        }

        public IEnumerable<Cervejeiro> FindByName(string nome)
        {
            //_db.Cervejeiros.FromSql($"Select * from Cervejeiro where Name LIKE %{name}%");

            return _db.Cervejeiros
                .Where(cli => EF.Functions
                .Like(cli.Nome, $"%{nome}%"));
        }

        public Cervejeiro Read(Guid id)
        {
            return _db.Cervejeiros.Find(id);
        }

        public IEnumerable<Cervejeiro> ReadAll()
        {
            return _db.Cervejeiros;
        }

        public void Update(Cervejeiro entity)
        {
            _db.Cervejeiros.Update(entity);
            _db.SaveChanges();
        }
    }
}
