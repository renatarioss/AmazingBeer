﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmazingBeer.DomainModel.Entities
{
    public class Checkin : EntityBase<Guid>
    {
        public DateTime Data { get; set; }
        public Guid IdCervejeiro { get; set; }
        public Cervejeiro Cervejeiro { get; set; }
        public Guid IdCerveja { get; set; }
        public Cerveja Cerveja { get; set; }
        public decimal Avaliacao { get; set; }
        public string Descricao { get; set; }
        public string Sabor { get; set; }
        public string Embalagem { get; set; }
    }
}
