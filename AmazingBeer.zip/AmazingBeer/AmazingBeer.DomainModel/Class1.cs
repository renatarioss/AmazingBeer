﻿using System;

namespace AmazingBeer.DomainModel
{
    public class Class1
    {
    }
}
