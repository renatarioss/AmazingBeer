﻿using AmazingBeer.DomainModel.Entities;
using AmazingBeer.DomainModel.Interfaces.Repositories;
using AmazingBeer.Infrastructure.DataAccess.Contexts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace AmazingBeer.Infrastructure.DataAccess.Repositories
{
    public class CervejaMemDbRepository : ICervejaRepository
    {
        private static readonly List<Cerveja> _set = new List<Cerveja>();

        public void Create(Cerveja entity)
        {
            _set.Add(entity);
        }

        public void Delete(Guid id)
        {
            _set.Remove(Read(id));
        }

        public IEnumerable<Cerveja> FindByName(string nome)
        {
            return ReadAll()
                .Where(cli => cli.Nome.ToLower()
                    .Contains(nome.ToLower()));
        }

        public Cerveja Read(Guid id)
        {
            return _set.Find(e => e.Id == id);
        }

        public IEnumerable<Cerveja> ReadAll()
        {
            return _set;
        }

        public void Update(Cerveja entity)
        {
            Delete(entity.Id);
            Create(entity);
        }
    }
}
