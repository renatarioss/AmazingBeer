﻿using AmazingBank.DomainModel.ValueObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace AmazingBank.DomainModel.Entities
{
    public class AmountTransaction : EntityBase<Guid>
    {
        public DateTime DateTime { get; set; }
        public Cervejeiro Origin { get; set; }
        public Cervejeiro Destiny { get; set; }
        public Amount Amount { get; set; }
    }
}
