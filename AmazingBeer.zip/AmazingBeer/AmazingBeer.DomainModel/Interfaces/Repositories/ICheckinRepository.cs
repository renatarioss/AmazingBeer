﻿using AmazingBeer.DomainModel.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace AmazingBeer.DomainModel.Interfaces.Repositories
{
    public interface ICheckinRepository : IRepository<Checkin, Guid>
    {
        IEnumerable<Checkin> FindByName(string nome);
    }
}
