﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AmazingBeer.DomainModel.Interfaces.Repositories;
using AmazingBeer.DomainModel.Entities;

namespace AmazingBeer.DomainService
{
    public class CervejeiroService
    {
        private ICervejeiroRepository _CervejeiroRepository;

        public CervejeiroService(ICervejeiroRepository CervejeiroRepository)
        {
            _CervejeiroRepository = CervejeiroRepository;
        }

        public void AddCervejeiro(Cervejeiro Cervejeiro)
        {
            _CervejeiroRepository.Create(Cervejeiro);
        }

        public IEnumerable<Cervejeiro> GetAllCervejeiros()
        {
            return _CervejeiroRepository.ReadAll();
        }

        public Cervejeiro GetCervejeiroById(Guid id)
        {
            return _CervejeiroRepository.Read(id);
        }

        public IEnumerable<Cervejeiro> SearchByName(string nome)
        {
            return _CervejeiroRepository.ReadAll()
                .Where(c => c.Nome.ToLower()
                .Contains(nome.ToLower()));
        }
    }
}
