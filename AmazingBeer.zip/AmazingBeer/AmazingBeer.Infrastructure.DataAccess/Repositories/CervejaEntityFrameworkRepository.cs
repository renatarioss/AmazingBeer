﻿using AmazingBeer.DomainModel.Entities;
using AmazingBeer.DomainModel.Interfaces.Repositories;
using AmazingBeer.Infrastructure.DataAccess.Contexts;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace AmazingBeer.Infrastructure.DataAccess.Repositories
{
    public class CervejaEntityFrameworkRepository : ICervejaRepository
    {
        private readonly AmazingBeerContext _db;

        public CervejaEntityFrameworkRepository(AmazingBeerContext db)
        {
            _db = db;
        }
  
        public void Create(Cerveja entity)
        {
            _db.Cervejas.Add(entity);
            _db.SaveChanges();
        }

        public void Delete(Guid id)
        {
            _db.Remove(Read(id));
            _db.SaveChanges();
        }

        public IEnumerable<Cerveja> FindByName(string nome)
        {
            //_db.Cervejeiros.FromSql($"Select * from Cervejeiro where Name LIKE %{name}%");

            return _db.Cervejas
                .Where(cli => EF.Functions
                .Like(cli.Nome, $"%{nome}%"));
        }

        public Cerveja Read(Guid id)
        {
            return _db.Cervejas.Find(id);
        }

        public IEnumerable<Cerveja> ReadAll()
        {
            return _db.Cervejas;
        }

        public void Update(Cerveja entity)
        {
            _db.Cervejas.Update(entity);
            _db.SaveChanges();
        }
    }
}
