﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmazingBeer.DomainModel.Entities
{
    public class Cervejeiro : EntityBase<Guid>
    {
        public string Nome { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Email { get; set; }
        public string Genero { get; set; }
        public string FotoUrl { get; set; }
    }
}
