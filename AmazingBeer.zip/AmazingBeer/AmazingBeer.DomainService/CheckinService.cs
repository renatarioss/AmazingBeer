﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AmazingBeer.DomainModel.Interfaces.Repositories;
using AmazingBeer.DomainModel.Entities;

namespace AmazingBeer.DomainService
{
    public class CheckinService
    {
        private ICheckinRepository _CheckinRepository;

        public CheckinService(ICheckinRepository CheckinRepository)
        {
            _CheckinRepository = CheckinRepository;
        }

        public void AddCheckin(Checkin Checkin)
        {
            _CheckinRepository.Create(Checkin);
        }

        public IEnumerable<Checkin> GetAllCheckins()
        {
            return _CheckinRepository.ReadAll();
        }

        public Checkin GetCheckinById(Guid id)
        {
            return _CheckinRepository.Read(id);
        }
    }
}
