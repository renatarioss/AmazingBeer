﻿using AmazingBeer.DomainModel.Entities;
using AmazingBeer.DomainModel.Interfaces.Repositories;
using AmazingBeer.Infrastructure.DataAccess.Contexts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace AmazingBeer.Infrastructure.DataAccess.Repositories
{
    public class FabricanteMemDbRepository : IFabricanteRepository
    {
        private static readonly List<Fabricante> _set = new List<Fabricante>();

        public void Create(Fabricante entity)
        {
            _set.Add(entity);
        }

        public void Delete(Guid id)
        {
            _set.Remove(Read(id));
        }

        public IEnumerable<Fabricante> FindByName(string nome)
        {
            return ReadAll()
                .Where(cli => cli.Nome.ToLower()
                    .Contains(nome.ToLower()));
        }

        public Fabricante Read(Guid id)
        {
            return _set.Find(e => e.Id == id);
        }

        public IEnumerable<Fabricante> ReadAll()
        {
            return _set;
        }

        public void Update(Fabricante entity)
        {
            Delete(entity.Id);
            Create(entity);
        }
    }
}
