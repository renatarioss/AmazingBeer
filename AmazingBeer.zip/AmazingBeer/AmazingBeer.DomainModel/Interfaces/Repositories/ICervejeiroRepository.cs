﻿using AmazingBeer.DomainModel.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace AmazingBeer.DomainModel.Interfaces.Repositories
{
    public interface ICervejeiroRepository : IRepository<Cervejeiro,Guid>
    {
        IEnumerable<Cervejeiro> FindByName(string nome);
    }
}
