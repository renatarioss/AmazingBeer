﻿using AmazingBeer.DomainModel.Entities;
using AmazingBeer.DomainModel.Interfaces.Repositories;
using AmazingBeer.Infrastructure.DataAccess.Contexts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace AmazingBeer.Infrastructure.DataAccess.Repositories
{
    public class CervejeiroMemDbRepository : ICervejeiroRepository
    {
        private static readonly List<Cervejeiro> _set = new List<Cervejeiro>();

        public void Create(Cervejeiro entity)
        {
            _set.Add(entity);
        }

        public void Delete(Guid id)
        {
            _set.Remove(Read(id));
        }

        public IEnumerable<Cervejeiro> FindByName(string nome)
        {
            return ReadAll()
                .Where(cli => cli.Nome.ToLower()
                    .Contains(nome.ToLower()));
        }

        public Cervejeiro Read(Guid id)
        {
            return _set.Find(e => e.Id == id);
        }

        public IEnumerable<Cervejeiro> ReadAll()
        {
            return _set;
        }

        public void Update(Cervejeiro entity)
        {
            Delete(entity.Id);
            Create(entity);
        }
    }
}
