﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AmazingBeer.DomainModel.Interfaces.Repositories;
using AmazingBeer.DomainModel.Entities;

namespace AmazingBeer.DomainService
{
    public class CervejaService
    {
        private ICervejaRepository _CervejaRepository;

        public CervejaService(ICervejaRepository CervejaRepository)
        {
            _CervejaRepository = CervejaRepository;
        }

        public void AddCerveja(Cerveja Cerveja)
        {
            _CervejaRepository.Create(Cerveja);
        }

        public IEnumerable<Cerveja> GetAllCervejas()
        {
            return _CervejaRepository.ReadAll();
        }

        public Cerveja GetCervejaById(Guid id)
        {
            return _CervejaRepository.Read(id);
        }

        public IEnumerable<Cerveja> SearchByName(string nome)
        {
            return _CervejaRepository.ReadAll()
                .Where(c => c.Nome.ToLower()
                .Contains(nome.ToLower()));
        }
    }
}
