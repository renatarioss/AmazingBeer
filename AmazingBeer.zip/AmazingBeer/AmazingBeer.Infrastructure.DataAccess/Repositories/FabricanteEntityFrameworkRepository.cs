﻿using AmazingBeer.DomainModel.Entities;
using AmazingBeer.DomainModel.Interfaces.Repositories;
using AmazingBeer.Infrastructure.DataAccess.Contexts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AmazingBeer.Infrastructure.DataAccess.Repositories
{
    public class FabricanteEntityFrameworkRepository : IFabricanteRepository
    {
        private readonly AmazingBeerContext _db;

        public FabricanteEntityFrameworkRepository(AmazingBeerContext db)
        {
            _db = db;
        }
  
        public void Create(Fabricante entity)
        {
            _db.Fabricantes.Add(entity);
            _db.SaveChanges();
        }

        public void Delete(Guid id)
        {
            _db.Remove(Read(id));
            _db.SaveChanges();
        }

        public IEnumerable<Fabricante> FindByName(string nome)
        {
            //_db.Cervejeiros.FromSql($"Select * from Cervejeiro where Name LIKE %{name}%");

            return _db.Fabricantes
                .Where(cli => EF.Functions
                .Like(cli.Nome, $"%{nome}%"));
        }

        public Fabricante Read(Guid id)
        {
            return _db.Fabricantes.Find(id);
        }

        public IEnumerable<Fabricante> ReadAll()
        {
            return _db.Fabricantes;
        }

        public void Update(Fabricante entity)
        {
            _db.Fabricantes.Update(entity);
            _db.SaveChanges();
        }
    }
}
