﻿using AmazingBank.DomainModel.ValueObjects;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace AmazingBank.DomainModel.Entities
{
    public class Cervejeiro : EntityBase<Guid>
    {
        public Cerveja Client { get; set; }
        public virtual ICollection<Fabricante> Documents { get; set; }
        public Amount Amount { get; set; }

        public Cervejeiro()
        {
            Documents = new List<Fabricante>();
        }
    }
}
