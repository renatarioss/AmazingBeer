﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AmazingBeer.DomainModel.Interfaces.Repositories;
using AmazingBeer.DomainModel.Entities;

namespace AmazingBeer.DomainService
{
    public class FabricanteService
    {
        private IFabricanteRepository _FabricanteRepository;

        public FabricanteService(IFabricanteRepository FabricanteRepository)
        {
            _FabricanteRepository = FabricanteRepository;
        }

        public void AddFabricante(Fabricante Fabricante)
        {
            _FabricanteRepository.Create(Fabricante);
        }

        public IEnumerable<Fabricante> GetAllFabricantes()
        {
            return _FabricanteRepository.ReadAll();
        }

        public Fabricante GetFabricanteById(Guid id)
        {
            return _FabricanteRepository.Read(id);
        }

        public IEnumerable<Fabricante> SearchByName(string nome)
        {
            return _FabricanteRepository.ReadAll()
                .Where(c => c.Nome.ToLower()
                .Contains(nome.ToLower()));
        }
    }
}
