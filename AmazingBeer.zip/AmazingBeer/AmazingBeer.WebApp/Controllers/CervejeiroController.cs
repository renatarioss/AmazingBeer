﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AmazingBeer.DomainModel.Entities;
using AmazingBeer.Infrastructure.DataAccess;
using AmazingBeer.Infrastructure.DataAccess.Contexts;
using AmazingBeer.Infrastructure.AzureStorage;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AmazingBeer.WebApp.Controllers
{
    public class CervejeiroController : Controller
    {
        private readonly AmazingBeerContext _context;

        public CervejeiroController()
        {
            AmazingBeerContext context = new AmazingBeerContext();
            _context = context;
        }

        // GET: /<controller>/
        public async Task<IActionResult> Index()
        {
            return View(await _context.Cervejeiros.ToListAsync());
        }

        // GET: Cervejeiro/Create
        public IActionResult Create()
        {
            return View();
        }

        // GET: Films/Create
        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Create([Bind("Nome, DataNascimento, Email, Genero, FotoUrl,Id")] Cervejeiro cervejeiro)
        {
            if (ModelState.IsValid)
            {
                cervejeiro.Id = Guid.NewGuid();
                _context.Add(cervejeiro);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(cervejeiro);
        }

        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cervejeiro = await _context.Cervejeiros
                .FirstOrDefaultAsync(m => m.Id == id);
            if (cervejeiro == null)
            {
                return NotFound();
            }

            return View(cervejeiro);
        }

        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cervejeiro = await _context.Cervejeiros.FindAsync(id);
            if (cervejeiro == null)
            {
                return NotFound();
            }
            return View(cervejeiro);
        }

        // POST: Cervejeiros/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Nome, DataNascimento, Email, Genero, FotoUrl,Id")] Cervejeiro cervejeiro)
        {
            if (id != cervejeiro.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(cervejeiro);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CervejeiroExists(cervejeiro.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(cervejeiro);
        }

        // GET: Cervejeiros/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cervejeiro = await _context.Cervejeiros
                .FirstOrDefaultAsync(m => m.Id == id);
            if (cervejeiro == null)
            {
                return NotFound();
            }

            return View(cervejeiro);
        }

        // POST: Cervejeiros/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var cervejeiro = await _context.Cervejeiros.FindAsync(id);
            _context.Cervejeiros.Remove(cervejeiro);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CervejeiroExists(Guid id)
        {
            return _context.Cervejeiros.Any(e => e.Id == id);
        }
    }
}
