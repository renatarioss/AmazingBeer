﻿using AmazingBeer.DomainModel.Entities;
using Microsoft.EntityFrameworkCore;

namespace AmazingBeer.Infrastructure.DataAccess.Contexts
{
    public class AmazingBeerContext : DbContext
    {
        public virtual DbSet<Cerveja> Cervejas { get; set; }
        public virtual DbSet<Cervejeiro> Cervejeiros { get; set; }
        public virtual DbSet<Fabricante> Fabricantes { get; set; }
        public virtual DbSet<Checkin> Checkins { get; set; }
        //public virtual DbSet<Sabor> Sabores { get; set; }
        //public virtual DbSet<Tipo> Tipos { get; set; }
        
        public AmazingBeerContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            optionsBuilder.UseSqlServer(Properties.Resources.
                ResourceManager.GetString("DbConnectionString"));
        }
    }
}
